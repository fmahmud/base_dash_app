# handle_todos.py

import os
import re

from dotenv import load_dotenv
from github import Github
load_dotenv("../.pre-commit.env")

TOKEN = os.getenv("GITHUB_TOKEN")
REPO_NAME = os.getenv("GITHUB_REPOSITORY")

github = Github(TOKEN)
repo = github.get_repo(REPO_NAME)


def process_file(filename):
    with open(filename, "r+") as f:
        content = f.readlines()

        for index, line in enumerate(content):
            if "#todo:" in line and "(issue:" not in line:
                start = max(0, index - 10)
                end = min(len(content), index + 11)
                surrounding_code = "".join(content[start:end])
                todo_comment = re.search(r'#todo: (.+)', line, re.I).group(1)
                issue_number = create_issue(filename, todo_comment, surrounding_code)
                content[index] = line.replace(f"#todo: {todo_comment}", f"#todo: {todo_comment} (issue: {issue_number})")

        with open(filename, "w") as out:
            out.writelines(content)


def create_issue(filename, todo, surrounding_code):
    # Assuming you have a function to authenticate with GitHub and create the issue
    issue_body = f"In file {filename}, found TODO: \n```\n{surrounding_code}\n```"
    issue = {
        'title': f'TODO: {todo}',
        'body': issue_body,
        'labels': ['todo', 'automated-issue']
    }
    response = github_api_create_issue(issue)  # This function should be implemented to create an issue via GitHub API
    return response.number


def github_api_create_issue(issue):
    """
    Create a GitHub issue.
    :param issue: A dictionary containing issue information.
    :param repo_name: The name of the repository.
    :return: Created issue object.
    """

    created_issue = repo.create_issue(
        title=issue['title'],
        body=issue['body'],
        labels=issue.get('labels')
    )
    return created_issue


def main():
    for line in os.popen('git diff --name-only --cached').readlines():
        filename = line.strip()
        if filename.endswith(('.py', '.js', '.md', '.txt')):  # Adjust for your needs
            process_file(filename)


if __name__ == "__main__":
    main()
